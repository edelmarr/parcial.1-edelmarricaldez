package faunasur;

public class Reptil extends Animal implements ILiberable {
    private static final double FACTOR_COSTO = 15.0; // Constante para el costo
    private double longitud;

    public Reptil(String codigo, String nombre, EstadoSalud estadoSalud, double longitud) {
        super(codigo, nombre, estadoSalud);
        if (longitud <= 0) {
            throw new IllegalArgumentException("La longitud debe ser estrictamente positiva.");
        }
        this.longitud = longitud;
    }

    public double getLongitud() {
        return longitud;
    }

    @Override
    public double calcularCostoDiario() {
        return this.longitud + FACTOR_COSTO;
    }

    @Override
    public String liberarse() {
        return "Liberando al reptil " + getNombre() + " a la reserva.";
    }

    @Override
    public String toString() {
        return "Reptil " + super.toString() + " - Longitud: " + longitud + " cm";
    }
}