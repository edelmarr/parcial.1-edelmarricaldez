package faunasur;

public class Ave extends Animal implements IRehabilitable, ILiberable {
    // Atributo final (constante) para evitar "números sueltos"
    private static final double FACTOR_COSTO = 2.0;
    private double envergaduraAlar;

    public Ave(String codigo, String nombre, EstadoSalud estadoSalud, double envergaduraAlar) {
        super(codigo, nombre, estadoSalud);
        if (envergaduraAlar <= 0) {
            throw new IllegalArgumentException("La envergadura alar debe ser estrictamente positiva.");
        }
        this.envergaduraAlar = envergaduraAlar;
    }

    public double getEnvergaduraAlar() {
        return envergaduraAlar;
    }

    @Override
    public double calcularCostoDiario() {
        // Se usa la constante en lugar de un número suelto
        return this.envergaduraAlar * FACTOR_COSTO;
    }

    @Override
    public String rehabilitar() {
        return "Rehabilitando al ave " + getNombre() + " (Código: " + getCodigo() + ")";
    }

    @Override
    public String liberarse() {
        // Implementación real, no vacía
        return "Liberando al ave " + getNombre() + " hacia su hábitat natural.";
    }

    @Override
    public String toString() {
        return "Ave " + super.toString() + " - Envergadura: " + envergaduraAlar + " cm";
    }
}