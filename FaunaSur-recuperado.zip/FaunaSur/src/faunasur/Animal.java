package faunasur;

import java.util.Objects;

public abstract class Animal {
    private String codigo;
    private String nombre;
    private EstadoSalud estadoSalud;
    
    public Animal(String codigo, String nombre, EstadoSalud estadoSalud){
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede ser nulo ni estar en blanco");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo ni estar en blanco");
        }
        if (estadoSalud == null) {
            throw new IllegalArgumentException("El estado de salud no puede ser nulo");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.estadoSalud = estadoSalud;
    }
    
    public String getCodigo() {
        return codigo;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    // Getter correcto y único
    public EstadoSalud getEstadoSalud() {
        return estadoSalud;
    }
    
    public void setEstadoSalud(EstadoSalud estadoSalud) {
        if (estadoSalud == null) {
            throw new IllegalArgumentException("El estado de salud no puede ser nulo");
        }
        this.estadoSalud = estadoSalud;
    }
    
    public abstract double calcularCostoDiario();
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || !(o instanceof Animal)) return false;
        Animal animal = (Animal) o;
        return Objects.equals(codigo, animal.codigo);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
    
    @Override
    public String toString() { 
        return String.format("[%s] %s - Estado: %s", codigo, nombre, estadoSalud);
    }
}