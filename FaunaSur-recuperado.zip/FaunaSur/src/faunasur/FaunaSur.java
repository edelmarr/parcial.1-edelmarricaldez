package faunasur;

import java.util.List;

public class FaunaSur {

    public static void main(String[] args) {
        CentroRescate centro = new CentroRescate("FaunaSur");

        try {
            centro.agregarAnimal(new Ave("AV-10", "Luna", EstadoSalud.EN_RECUPERACION, 80));
            centro.agregarAnimal(new Mamifero("MA-20", "Puma", EstadoSalud.EN_RECUPERACION, 12));
            centro.agregarAnimal(new Reptil("RE-30", "Sol", EstadoSalud.ESTABLE, 65));
            centro.agregarAnimal(new Ave("AV-40", "Nube", EstadoSalud.CRITICO, 50));
            
            
            centro.agregarAnimal(new Reptil("AV-10", "Luna", EstadoSalud.CRITICO, 90));
            
        } catch (AnimalDupException e) {
            System.err.println("Excepcion capturada: " + e.getMessage());
        }

        System.out.println("\nAnimales registrados:");
        mostrarAnimales(centro.obtenerAnimales());

        System.out.println("\nRehabilitaciones:");
        mostrarRehabilitaciones(centro.obtenerAnimales());

        System.out.println("\nLiberaciones:");
        mostrarLiberaciones(centro.obtenerAnimales());

        System.out.println("\nCosto diario de cada animal:");
        mostrarCostos(centro.obtenerAnimales());

        System.out.println("\nAnimales ESTABLES:");
        mostrarAnimales(centro.filtrarPorEstado(EstadoSalud.ESTABLE));

        System.out.println("\nAnimales con costo diario hasta 100:");
        mostrarAnimales(centro.obtenerAnimalesConCostoMaximo(100));
    }

    private static void mostrarAnimales(List<Animal> animales) {
        for (Animal a : animales) {
            System.out.println(a);
        }
    }

    private static void mostrarRehabilitaciones(List<Animal> animales) {
        for (Animal a : animales) {
            if (a instanceof IRehabilitable) {
                IRehabilitable rehabilitable = (IRehabilitable) a;
                System.out.println(rehabilitable.rehabilitar());
            }
        }
    }

    private static void mostrarLiberaciones(List<Animal> animales) {
        for (Animal a : animales) {
            if (a instanceof ILiberable) {
                ILiberable liberable = (ILiberable) a;
                System.out.println(liberable.liberarse());
            }
        }
    }

    private static void mostrarCostos(List<Animal> animales) {
        for (Animal a : animales) {
            System.out.println(a.getNombre() + " (" + a.getCodigo() + "): $" + a.calcularCostoDiario());
        }
    }
}