package sistemagestionrobots;


public class RobotReparto extends Robot implements IServiciable{
    private int capacidadCarga;
    
    public RobotReparto(String numeroSerie, String fabricante, Prioridad prioridad, int bateria, int capacidadCarga){
        super(numeroSerie, fabricante, prioridad, bateria);
        this.capacidadCarga = capacidadCarga;
}
    
    public int getcapacidadCarga() {return capacidadCarga; }
    
    @Override
    public int calcularConsumo(){
        return (capacidadCarga * 3) + 4;
    }
    
    @Override 
    public void ejecutarServicio(){
        int consumo = calcularConsumo();
        if (bateria < consumo) {
            throw new IllegalStateException("Bateria insuficiente");
        }
        bateria -= consumo;
    }
    
    @Override
    public String toString() {
        return "RobotReparto [serie " + numeroSerie + ", fabricante " + fabricante +
                ", prioridad " + prioridad + ", bateria = "+ bateria + ", carga = " + capacidadCarga + "]";
    }

}
