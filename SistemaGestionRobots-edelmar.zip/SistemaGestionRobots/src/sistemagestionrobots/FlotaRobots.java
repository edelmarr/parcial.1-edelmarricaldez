
package sistemagestionrobots;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class FlotaRobots {
    private String nombre;
    private List<Robot> robots;
    
    public FlotaRobots(String nombre){
        this.nombre = nombre;
        this.robots = new ArrayList<>();
    }
    
    public String getNombre() {return nombre;}
    
    public void agregarRobot(Robot r) throws RobotDuplicadoException {
        for (Robot existing : robots) {
            if (existing.equals(r)){
                throw new RobotDuplicadoException("Ya existe un robot con serie" + r.getNumeroSerie() + " y fabricante "+ r.getFabricante() + ".");
            }
        }
        robots.add(r);
    }
    
    public List<Robot> obtenerRobots() {
        return new ArrayList<>(robots);
    }
    public List<Robot> filtrarPorPrioridad(Prioridad prioridad){
        return robots.stream()
                .filter(r -> r.getPrioridad() == prioridad)
                .collect(Collectors.toList());
    }
    
    public List<Robot> obtenerRobotConConsumoMaximo(int maximo){
        return robots.stream()
                .filter(r -> r.calcularConsumo() == maximo)
                .collect(Collectors.toList());
                
    }

   
}
