package sistemagestionrobots;

import java.util.List;


public class SistemaGestionRobots {

     
    public static void main(String[] args) {
        FlotaRobots flota = new FlotaRobots("TecnoAsistencia");
        
        try {
            flota.agregarRobot(new RobotLimpieza("RL-10", "pepe", Prioridad.ALTA, 60, 80));
            flota.agregarRobot(new RobotVigilancia("RV-20", "choco", Prioridad.MEDIA, 75, 3));
            flota.agregarRobot(new RobotReparto("RR-30", "pepe", Prioridad.BAJA, 40, 5));
            flota.agregarRobot(new RobotReparto("RR-40", "choco", Prioridad.ALTA, 15, 4));
            flota.agregarRobot(new RobotVigilancia("RL-10", "pepe", Prioridad.BAJA, 90, 2));
        }catch(RobotDuplicadoException e){
            System.out.println("No se puedo agregar: " + e.getMessage());
        }
        
        System.out.println("Robots registrados: ");
        mostrarRobots(flota.obtenerRobots());
        
        System.out.println("\nEjecucion de servicios:");
        ejecutarServicios(flota.obtenerRobots());
        
        System.out.println("\nDiagnosticos:");
        generarDiagnostico(flota.obtenerRobots());
        
        System.out.println("\nRobots de prioridad ALTA:");
        mostrarRobots(flota.filtrarPorPrioridad(Prioridad.ALTA));
        
        System.out.println("\nRobots con consumo maximo de 18:");
        mostrarRobots(flota.obtenerRobotConConsumoMaximo(18));
        
        System.out.println("\nConsumos actuales:");
        mostrarConsumos(flota.obtenerRobots());
        
        
        
        
        
        
    }

    private static void mostrarRobots(List<Robot> robots) {
        for (Robot r : robots){
            System.out.println(r);
        }
    }

    private static void ejecutarServicios(List<Robot> robots) {
        for (Robot r : robots) {
            if (r instanceof IServiciable) {
                IServiciable s = (IServiciable) r;
                try {
                    s.ejecutarServicio();
                    if (r instanceof RobotLimpieza) {
                        System.out.println("Servicio de limpieza " + r.getNumeroSerie() + " ejecutado");
                    } else if (r instanceof RobotReparto) {
                        System.out.println("Servicio de reparto " + r.getNumeroSerie() + " ejecutado");
                    }
                }catch (IllegalStateException e) {
                    System.out.println("no se puedo ejecutar " + r.getNumeroSerie() + ": Bateria insificiente");
                }
            }else {
                System.out.println("El robot " + r.getNumeroSerie() + " no ejecuta");
            }
        }
    }

    private static void generarDiagnostico(List<Robot> robots) {
        for (Robot r : robots){
            if (r instanceof IDiagnosticable) {
                IDiagnosticable d = (IDiagnosticable) r;
                System.out.println(d.generarDiagnostico());
            }else{
                System.out.println("El robot " + r.getNumeroSerie() + " no genera diagnostico");
            }
        }
    }

    private static void mostrarConsumos(List<Robot> robots) {
        for (Robot r : robots) {
            System.out.println(r.getNumeroSerie() + ":" + r.calcularConsumo() + " puntos de bateria por operacion");
        }
    }
    
}
