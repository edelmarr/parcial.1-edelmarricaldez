/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrobots;

/**
 *
 * @author rical
 */
public class RobotVigilancia extends Robot implements IDiagnosticable{
    private int cantidadCamaras;
    
    public RobotVigilancia(String numeroSerie, String fabricante, Prioridad prioridad, int bateria, int cantidadCamaras) {
        super(numeroSerie, fabricante, prioridad, bateria);
        this.cantidadCamaras = cantidadCamaras;
    }
    
    public int getCantidadCamaras() {return cantidadCamaras; }
    
    @Override
    public int calcularConsumo(){
        return (cantidadCamaras * 4) + 6;
    }
    
    @Override
    public String generarDiagnostico(){
        return "Diagnostico de vigilancia" + numeroSerie + ": " + cantidadCamaras + " camaras operativas";
    }
    
    @Override
    public String toString() {
        return "RobotVigilancia [serie " + numeroSerie + ", fabricante " + fabricante +
                ", prioridad " + prioridad + ", bateria = "+ bateria + ", camaras = " + cantidadCamaras + "]";
    }
    
    
}
