package sistemagestionrobots;


public class RobotLimpieza extends Robot implements IServiciable{
    private int superficie;
    
    public RobotLimpieza(String numeroSerie, String fabricante, Prioridad prioridad, int bateria, int superficie){
        super(numeroSerie, fabricante, prioridad, bateria);
        this.superficie = superficie;
}
    
    public int getSuperficie() {return superficie; }
    
    @Override
    public int calcularConsumo(){
        return (superficie / 10) + 5;
    }
    
    @Override 
    public void ejecutarServicio(){
        int consumo = calcularConsumo();
        if (bateria < consumo) {
            throw new IllegalStateException("Bateria insuficiente");
        }
        bateria -= consumo;
    }
    
    @Override
    public String toString() {
        return "RobotLimpieza [serie " + numeroSerie + ", fabricante " + fabricante +
                ", prioridad " + prioridad + ", bateria = "+ bateria + ", superficie = " + superficie + "]";
    }

}
