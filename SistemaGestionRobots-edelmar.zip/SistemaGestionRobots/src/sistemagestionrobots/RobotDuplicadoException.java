/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestionrobots;

/**
 *
 * @author rical
 */
public class RobotDuplicadoException extends RuntimeException{
    public RobotDuplicadoException(String mensaje){
        super(mensaje);
    }
    
}
