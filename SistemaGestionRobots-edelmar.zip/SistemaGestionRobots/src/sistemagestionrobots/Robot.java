package sistemagestionrobots;

import java.util.Objects;



public abstract class Robot {
    protected String numeroSerie;
    protected String fabricante;
    protected Prioridad prioridad;
    protected int bateria;
    
    public Robot(String numeroSerie, String fabricante, Prioridad prioridad, int batrerias) {
        this.numeroSerie = numeroSerie;
        this.fabricante = fabricante;
        this.prioridad = prioridad;
        this.bateria = bateria;
    }
    
    public String getNumeroSerie() {return numeroSerie; }
    public String getFabricante() {return fabricante; }
    public Prioridad getPrioridad() {return prioridad; }
    public int getBateria() {return bateria; }
    public void setBateria(int bateria) {this.bateria = bateria;}
    
    public abstract int calcularConsumo();
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Robot robot = (Robot) o;
        return Objects.equals(numeroSerie, robot.numeroSerie) &&
                Objects.equals(fabricante, robot.fabricante);
        
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(numeroSerie, fabricante);
    }
    
}
