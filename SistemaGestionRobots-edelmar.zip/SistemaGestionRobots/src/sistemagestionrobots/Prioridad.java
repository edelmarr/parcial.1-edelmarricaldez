
package sistemagestionrobots;


public enum Prioridad {
    BAJA,MEDIA,ALTA
    
}
